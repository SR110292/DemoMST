package testDatatypes;

import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class CardDetails {

public String email;
public String expiry;
public String cvc;
public String zip;

}

